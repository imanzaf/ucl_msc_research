# Scenario generation package v4.0.0

Contents:

- `scenario_generation_seeds_v4.0.0.json`: 6 use cases × 5 evaluation replications.
- `scenario_generation_seed_schema_v4.0.0.json`: structural schema for the seed.
- `scenario_inventory_v4.0.0.csv`: human-readable inventory of all 30 decisions.
- `generated_scenario_schema_v4.0.0.json`: expected fact-generation output.
- `fact_generation_prompt_v4.0.0.md`: suggested system prompt for the fact-generation model.
- `design_and_scoring_recommendations_v4.0.0.md`: experiment and measurement redesign.
- `recommended_experiment_matrix_v4.0.0.json`: operational separation of the four proposed experiments.
- `reference_scoring_v4.py`: reference implementation of the decomposed outcomes and ownership contrast.
- `validate_seed_v4.py`: semantic validation of counts, counterbalancing and fact-pair invariants.
- `build_generation_requests_v4.py`: adapter that renders one schema-constrained chat request per scenario.
- `generation_requests_v4.0.0.jsonl`: 30 ready-rendered generation requests.

Run validation from this directory:

```bash
python validate_seed_v4.py scenario_generation_seeds_v4.0.0.json
```

The seed is a design brief. Generated facts remain synthetic and require a blinded financial-plausibility and arithmetic review before acceptance.

Render the requests again after editing the seed:

```bash
python build_generation_requests_v4.py
```

The old v3 loader/schema cannot accept five replications and six facts unchanged; use the supplied v4 schemas or the rendered JSONL adapter.
