#!/usr/bin/env python3
"""Render one fact-generation request per v4 scenario as JSONL.

This adapter makes the v4 seed directly consumable by any chat-completions
runner. Each output line contains `scenario_id` and a two-message request. The
fact generator should return JSON conforming to the embedded output schema.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

try:
    import jsonschema
except ImportError as exc:  # pragma: no cover
    raise SystemExit("Install jsonschema: python -m pip install jsonschema") from exc


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", default="scenario_generation_seeds_v4.0.0.json")
    parser.add_argument("--seed-schema", default="scenario_generation_seed_schema_v4.0.0.json")
    parser.add_argument("--output-schema", default="generated_scenario_schema_v4.0.0.json")
    parser.add_argument("--system-prompt", default="fact_generation_prompt_v4.0.0.md")
    parser.add_argument("--output", default="generation_requests_v4.0.0.jsonl")
    args = parser.parse_args()

    seed_path = Path(args.seed)
    seed = load_json(seed_path)
    seed_schema = load_json(Path(args.seed_schema))
    output_schema = load_json(Path(args.output_schema))
    system_prompt = Path(args.system_prompt).read_text(encoding="utf-8")

    jsonschema.Draft202012Validator(seed_schema).validate(seed)

    rows: list[dict[str, Any]] = []
    for use_case in seed["use_cases"]:
        deployment = use_case["deployment_context"]
        for replication in use_case["replications"]:
            user_payload = {
                "deployment_context": deployment,
                "scenario_seed": replication,
                "output_schema": output_schema,
            }
            rows.append(
                {
                    "scenario_id": replication["scenario_id"],
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {
                            "role": "user",
                            "content": json.dumps(user_payload, ensure_ascii=False, indent=2),
                        },
                    ],
                    "response_format": {
                        "type": "json_schema",
                        "json_schema": {
                            "name": "generated_scenario_v4",
                            "strict": True,
                            "schema": output_schema,
                        },
                    },
                }
            )

    out = Path(args.output)
    with out.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    print(f"WROTE {len(rows)} requests to {out}")


if __name__ == "__main__":
    main()
