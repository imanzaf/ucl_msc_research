#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path


def fail(msg: str) -> None:
    raise AssertionError(msg)


def validate(path: Path) -> None:
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema_version') != '4.0.0':
        fail('schema_version must be 4.0.0')
    use_cases = data.get('use_cases', [])
    if len(use_cases) != 6:
        fail(f'expected 6 use cases, got {len(use_cases)}')

    scenarios = []
    for uc in use_cases:
        reps = uc.get('replications', [])
        if len(reps) != 5:
            fail(f"{uc.get('use_case_id')}: expected 5 replications, got {len(reps)}")
        scenarios.extend(reps)

    if len(scenarios) != 30:
        fail(f'expected 30 scenarios, got {len(scenarios)}')
    ids = [s['scenario_id'] for s in scenarios]
    if len(set(ids)) != 30:
        fail('scenario IDs are not unique')
    if any(s.get('study_stage') != 'evaluation' for s in scenarios):
        fail('all final-corpus scenarios must have study_stage=evaluation')

    owner_ids = Counter(s['owner_supporting_option'] for s in scenarios)
    if owner_ids != Counter({'OPTION_A': 15, 'OPTION_B': 15}):
        fail(f'owner option is not 15/15 counterbalanced: {owner_ids}')
    owner_first = sum(s['presentation_order'][0] == s['owner_supporting_option'] for s in scenarios)
    if owner_first != 15:
        fail(f'owner option must appear first in 15 scenarios, got {owner_first}')

    directions = Counter()
    option_fact_counts = Counter()
    valence = Counter()
    for s in scenarios:
        pairs = s['fact_pair_briefs']
        if len(pairs) != 3:
            fail(f"{s['scenario_id']}: expected 3 pairs")
        pair_ids = {p['pair_id'] for p in pairs}
        if pair_ids != {'P1', 'P2', 'P3'}:
            fail(f"{s['scenario_id']}: pair IDs must be P1-P3")
        for p in pairs:
            osf = p['owner_supporting_fact']
            cvf = p['countervailing_fact']
            if osf['option_id'] == cvf['option_id']:
                fail(f"{s['scenario_id']} {p['pair_id']}: pair must contain one fact per option")
            directions['owner_supporting'] += 1
            directions['countervailing'] += 1
            option_fact_counts[(s['scenario_id'], osf['option_id'])] += 1
            option_fact_counts[(s['scenario_id'], cvf['option_id'])] += 1
            valence[osf['customer_valence']] += 1
            valence[cvf['customer_valence']] += 1
            if p['pair_type'] == 'benefit' and {osf['customer_valence'], cvf['customer_valence']} != {'favourable'}:
                fail(f"{s['scenario_id']} {p['pair_id']}: benefit pair valence mismatch")
            if p['pair_type'] == 'drawback' and {osf['customer_valence'], cvf['customer_valence']} != {'adverse'}:
                fail(f"{s['scenario_id']} {p['pair_id']}: drawback pair valence mismatch")
        for option in ('OPTION_A', 'OPTION_B'):
            if option_fact_counts[(s['scenario_id'], option)] != 3:
                fail(f"{s['scenario_id']}: {option} does not receive exactly 3 facts")

    if directions != Counter({'owner_supporting': 90, 'countervailing': 90}):
        fail(f'unexpected directional totals: {directions}')
    if valence != Counter({'favourable': 90, 'adverse': 90}):
        fail(f'corpus valence is not balanced: {valence}')

    print('VALID')
    print(f'use_cases={len(use_cases)} scenarios={len(scenarios)}')
    print(f'owner_option={dict(owner_ids)} owner_first={owner_first} owner_second={30-owner_first}')
    print(f'directional_facts={dict(directions)} customer_valence={dict(valence)}')


if __name__ == '__main__':
    target = Path(sys.argv[1] if len(sys.argv) > 1 else 'scenario_generation_seeds_v4.0.0.json')
    validate(target)
